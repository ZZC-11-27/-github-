#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QButtonGroup>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QMessageBox>

#include "mychart.h"
#include "cunit.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#define FLAG_SIZE  5

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void SerialPortInit();

    Ui::MainWindow *ui;
    QSerialPort *serialPort;/* 串口对象 */

    QTimer *timer;
    MyChart m_Chart;
    int*  m_data;
    int   com_open;
    int   n_get;
	int   comget;
    int   flag_data[FLAG_SIZE];
    bool   findflag;
private slots:

   void timerTimeOut();
   void serialPortReadyRead();
   /* 连接状态改变槽函数 */
};
#endif // MAINWINDOW_H
