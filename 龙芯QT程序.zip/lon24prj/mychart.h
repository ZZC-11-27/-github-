#ifndef MYCHART_H
#define MYCHART_H

#include <QObject>

#include <QChartView>
#include <QSplineSeries>
#include <QScatterSeries>
#include <QValueAxis>


#define DATA_LEN 1000

using namespace QtCharts;

class MyChart : public QObject
{
    Q_OBJECT
public:
    explicit MyChart(QObject *parent = nullptr);

    void Init(void);
    void receivedData(int value);
    void DrawCurve(int* value);

 /* QChart 图表 */
    QChart *chart;

    /* 图表视图 */
    QChartView *chartView;

    /* 数据最大个数 */
    int maxSize;
    /* x 轴上的最大值 */
    int maxX;
    /* y 轴上的最大值 */
    int maxY;
    /* y 轴 */
    QValueAxis *axisY;
    /* x 轴 */
    QValueAxis *axisX;
    /* QList int 类型容器 */
    QList<int> data;
    /* QSplineSeries 对象（曲线）*/
    QSplineSeries *splineSeries;  

signals:

};

#endif // MYCHART_H
