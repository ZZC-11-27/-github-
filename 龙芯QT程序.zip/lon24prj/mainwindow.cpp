#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QTimer>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_Chart.Init();
    QWidget *vWidget=new QWidget(this);
    vWidget->setGeometry(0, 20, 800, 460);
    QVBoxLayout *vBoxLayout = new QVBoxLayout();
    vBoxLayout->addWidget(m_Chart.chartView);
    vWidget->setLayout(vBoxLayout);

     com_open=0;
    // first_show=0;
     m_data = new int[DATA_LEN];
     serialPort = new QSerialPort(this);
	 SerialPortInit();
    //ButtonGroup信号链接
    //  timer = new QTimer(this);
    //  timer->start(1000);
    /* 信号槽连接 */
    //  connect(timer, SIGNAL(timeout()), this, SLOT(timerTimeOut()));
      connect(serialPort, SIGNAL(readyRead()), this, SLOT(serialPortReadyRead()));
     /* 设置随机种子，随机数初始化 */
     //qsrand(time(NULL));
	 
 }

 MainWindow::~MainWindow()
 {
     delete ui;
 }  

void MainWindow::timerTimeOut()
{
    if(com_open==0)
    {
       SerialPortInit();
       n_get=0;
	   comget=0;
       findflag=true;
    }
    else if(com_open==1)
    {
        for(int i=0;i<DATA_LEN;i++)
            m_data[i]=qrand()%100;
       m_Chart.DrawCurve(m_data);
    }
}

void MainWindow::SerialPortInit()
{
    serialPort->setPortName(QString("ttyS1"));
    serialPort->setBaudRate(115200);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->setFlowControl(QSerialPort::NoFlowControl);
    if (serialPort->open(QIODevice::ReadWrite))
	{
		com_open=1;
		n_get=0;
	    comget=0;
        findflag=true;
	}
    else
    {
        QMessageBox::about(NULL, "err","COM Open err！");
        com_open=4;
    }
}

void MainWindow::serialPortReadyRead()
{
    int i,k,n,a,s;	
     /* 接收缓冲区中读取数据 */
    QByteArray buf = serialPort->readAll();
    n= buf.size();
	comget+=n;
    for(i=0;i<n;i++)
    {
        if(n_get<DATA_LEN)
        {
            a=buf.at(i);
            if(a>128)
                a=a-256;
             m_data[n_get++]=a;
            if(n_get==FLAG_SIZE && !findflag)
            {
                s=0;
                for(k=0;k<FLAG_SIZE;k++)
                   s+=(flag_data[k]-m_data[k])*(flag_data[k]-m_data[k]);
                if(s>5)
                 {
                    for(k=0;k<FLAG_SIZE-1;k++)
                       m_data[k]=m_data[k+1];
                //       n_get--;
                 }
                else
                    findflag=true;
            }
        }
		
		if(n_get==DATA_LEN)
		{
			m_Chart.DrawCurve(m_data);
			// first_show
			for(i=0;i<FLAG_SIZE;i++)
				flag_data[i]=m_data[i];
			findflag = false;
			n_get=0;
			comget=0;
			//serialPort->clear();
			//break;
		}
		
    }
    
	
	 if(comget>DATA_LEN)
	{
		findflag=true;
		n_get=0;
		comget=0;
	} 

    //textBrowser->insertPlainText(QString(buf));
}


